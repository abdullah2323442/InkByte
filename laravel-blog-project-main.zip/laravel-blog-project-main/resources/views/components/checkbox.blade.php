<input type="checkbox" {!! $attributes->merge(['class' => 'rounded border-gray-300 text-yellow-600 shadow-sm focus:ring-yellow-500']) !!}>
