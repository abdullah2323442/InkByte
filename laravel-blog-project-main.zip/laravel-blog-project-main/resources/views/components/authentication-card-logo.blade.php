<a href="/">
    <div class="text-gray-800 font-semibold">
        <span class="text-yellow-500 text-3xl">&lt;YELO&gt;</span> Code
    </div>
</a>
