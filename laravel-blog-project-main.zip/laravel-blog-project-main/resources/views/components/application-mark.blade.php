<div class="text-gray-800 font-semibold">
    <span class="text-yellow-500 text-xl">&lt;YELO&gt;</span>
</div>
