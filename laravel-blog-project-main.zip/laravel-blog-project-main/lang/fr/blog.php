<?php

return [

    'containing' => 'Contenant',

    'popular' => 'Populaire',
    'latest' => 'Dernière',
    'oldest' => 'Le plus ancien',

    'search' => 'Recherche',
    'search_placeholder' => 'Recherche ...',
    'recommended_topics' => 'Sujets recommandés'
];
