<?php


return [

    'featured_posts' => 'Postes en vedette',
    'latest_posts' => 'Derniers messages',
    'more_posts' => 'Plus de messages',

    'hero' => [
        'title' => 'Bienvenue à',
        'desc' => "Meilleur blog de l'univers",
        'cta' => 'Commencer la lecture'
    ]
];
