<?php


return [

    'featured_posts' => 'Featured Posts',
    'latest_posts' => 'Latest Posts',
    'more_posts' => 'More Posts',

    'hero' => [
        'title' => 'Welcome to',
        'desc' => 'Best Blog in the universe',
        'cta' => 'Start Reading'
    ]
];
