<?php

return [

    'containing' => 'Containing',

    'popular' => 'Popular',
    'latest' => 'Latest',
    'oldest' => 'Oldest',

    'search' => 'Search',
    'search_placeholder' => 'Search ...',
    'recommended_topics' => 'Recommended Topics',
    'min_read' => 'Min read'
];
