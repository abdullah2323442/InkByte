<?php


return [
    'home' => 'Home',
    'blog' => 'Blog',
    'admin' => 'Admin',
    'profile' => 'Profile',
    'login' => 'Login',
    'register' => 'Register',
    'logout' => 'Log out',
    'manage_account' => 'Manage Account',
];
